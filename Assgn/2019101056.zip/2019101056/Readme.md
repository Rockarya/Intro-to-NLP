For running language model file:
run: python3 language_model.py q1_english.pt
Propmt will open, where u need to write an english sentence and corresponding probability and perplexity will be returned

For running machine_translation file
run: python3 machine_translation.py q2.1_train.pt
Propmt will open, where u need to write an english sentence and corresponding translated French sentence will be returned
